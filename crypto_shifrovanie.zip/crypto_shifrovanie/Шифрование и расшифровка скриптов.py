import os
import subprocess
import io
import pyperclip
from cryptography.fernet import Fernet, InvalidToken
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
    QLineEdit, QPushButton, QFileDialog, QMessageBox, QStackedWidget
)

class EncryptionApp(QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        self.stacked_widget = stacked_widget
        self.setWindowTitle('Шифрование файлов')
        self.layout = QVBoxLayout()

        self.file_label = QLabel('Выберите файл для шифрования/расшифрования:')
        self.file_line_edit = QLineEdit()
        self.file_button = QPushButton('Обзор')
        self.file_button.clicked.connect(self.browse_file)

        self.key_label = QLabel('Введите ключ шифрования:')
        self.key_line_edit = QLineEdit()
        self.key_line_edit.setEchoMode(QLineEdit.EchoMode.Password)

        self.encrypt_button = QPushButton('Зашифровать')
        self.encrypt_button.clicked.connect(self.encrypt_file)

        self.decrypt_button = QPushButton('Расшифровать и запустить')
        self.decrypt_button.clicked.connect(self.decrypt_and_execute_file)

        self.switch_to_keygen_button = QPushButton('Перейти к генерации ключей')
        self.switch_to_keygen_button.clicked.connect(self.switch_to_keygen)

        self.layout.addWidget(self.file_label)
        self.layout.addWidget(self.file_line_edit)
        self.layout.addWidget(self.file_button)
        self.layout.addWidget(self.key_label)
        self.layout.addWidget(self.key_line_edit)
        self.layout.addWidget(self.encrypt_button)
        self.layout.addWidget(self.decrypt_button)
        self.layout.addWidget(self.switch_to_keygen_button)

        self.setLayout(self.layout)

    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, 'Выберите файл')
        self.file_line_edit.setText(file_path)

    def encrypt_file(self):
        file_path = self.file_line_edit.text()
        if not os.path.isfile(file_path):
            QMessageBox.warning(self, 'Ошибка', 'Файл не найден.')
            return

        key = self.key_line_edit.text().encode()
        if len(key) != 44:
            QMessageBox.warning(self, 'Ошибка', 'Неправильная длина ключа шифрования.')
            return

        cipher_suite = Fernet(key)

        with open(file_path, 'rb') as file:
            original_data = file.read()

        encrypted_data = cipher_suite.encrypt(original_data)

        encrypted_file_path = os.path.splitext(file_path)[0] + '.enc'
        with open(encrypted_file_path, 'wb') as file:
            file.write(encrypted_data)

        QMessageBox.information(self, 'Успех', f'Файл успешно зашифрован и сохранен в {encrypted_file_path}')

    def decrypt_and_execute_file(self):
        file_path = self.file_line_edit.text()
        if not os.path.isfile(file_path):
            QMessageBox.warning(self, 'Ошибка', 'Файл не найден.')
            return

        key = self.key_line_edit.text().encode()
        if len(key) != 44:
            QMessageBox.warning(self, 'Ошибка', 'Неправильная длина ключа шифрования.')
            return

        cipher_suite = Fernet(key)

        with open(file_path, 'rb') as file:
            encrypted_data = file.read()

        try:
            decrypted_data = cipher_suite.decrypt(encrypted_data)
        except InvalidToken:
            QMessageBox.warning(self, 'Ошибка', 'Неверный ключ шифрования или файл поврежден.')
            return

        temp_file_path = 'temp_decrypted_script.py'
        with open(temp_file_path, 'wb') as temp_file:
            temp_file.write(decrypted_data)

        try:
            subprocess.run(['python', temp_file_path])
        finally:
            os.remove(temp_file_path)

    def switch_to_keygen(self):
        self.stacked_widget.setCurrentIndex(1)

class KeyGeneratorApp(QWidget):
    def __init__(self, stacked_widget):
        super().__init__()
        self.stacked_widget = stacked_widget
        self.setWindowTitle('Генератор ключей шифрования')
        self.layout = QVBoxLayout()

        self.key_label = QLabel('Сгенерированный ключ:')
        self.key_label.setWordWrap(True)

        self.generate_button = QPushButton('Сгенерировать ключ')
        self.generate_button.clicked.connect(self.generate_key)

        self.copy_button = QPushButton('Скопировать ключ')
        self.copy_button.setEnabled(False)
        self.copy_button.clicked.connect(self.copy_key)

        self.switch_to_encrypt_button = QPushButton('Перейти к шифрованию файлов')
        self.switch_to_encrypt_button.clicked.connect(self.switch_to_encrypt)

        self.layout.addWidget(self.key_label)
        self.layout.addWidget(self.generate_button)
        self.layout.addWidget(self.copy_button)
        self.layout.addWidget(self.switch_to_encrypt_button)

        self.setLayout(self.layout)

    def generate_key(self):
        key = Fernet.generate_key()
        key_base64 = key.decode()
        self.key_label.setText(f'Сгенерированный ключ:\n{key_base64}')
        self.copy_button.setEnabled(True)
        QMessageBox.information(self, 'Успех', 'Ключ шифрования успешно сгенерирован и отображен.')

    def copy_key(self):
        key = self.key_label.text().split('\n')[1]
        pyperclip.copy(key)
        QMessageBox.information(self, 'Успех', 'Ключ шифрования успешно скопирован в буфер обмена.')

    def switch_to_encrypt(self):
        self.stacked_widget.setCurrentIndex(0)

class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Шифрование файлов и Генератор ключей')
        self.stacked_widget = QStackedWidget()
        
        self.encryption_app = EncryptionApp(self.stacked_widget)
        self.key_generator_app = KeyGeneratorApp(self.stacked_widget)
        
        self.stacked_widget.addWidget(self.encryption_app)
        self.stacked_widget.addWidget(self.key_generator_app)
        
        layout = QVBoxLayout()
        layout.addWidget(self.stacked_widget)
        self.setLayout(layout)

if __name__ == '__main__':
    app = QApplication([])
    main_app = MainApp()
    main_app.show()
    app.exec()
