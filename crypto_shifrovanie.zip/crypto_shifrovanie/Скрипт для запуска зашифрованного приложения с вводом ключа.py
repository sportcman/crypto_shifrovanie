import os
import io
import subprocess
from cryptography.fernet import Fernet
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, 
    QLineEdit, QPushButton, QFileDialog, QMessageBox
)

class EncryptedScriptExecutor(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Запуск зашифрованного скрипта')
        self.layout = QVBoxLayout()

        self.file_label = QLabel('Выберите зашифрованный скрипт:')
        self.file_line_edit = QLineEdit()
        self.file_button = QPushButton('Обзор')
        self.file_button.clicked.connect(self.browse_file)

        self.key_label = QLabel('Введите ключ для расшифровки:')
        self.key_line_edit = QLineEdit()

        self.run_script_button = QPushButton('Расшифровать и выполнить скрипт')
        self.run_script_button.clicked.connect(self.decrypt_and_execute_script)

        self.layout.addWidget(self.file_label)
        self.layout.addWidget(self.file_line_edit)
        self.layout.addWidget(self.file_button)
        self.layout.addWidget(self.key_label)
        self.layout.addWidget(self.key_line_edit)
        self.layout.addWidget(self.run_script_button)

        self.setLayout(self.layout)

    def browse_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, 'Выберите зашифрованный скрипт')
        self.file_line_edit.setText(file_path)

    def decrypt_and_execute_script(self):
        file_path = self.file_line_edit.text()
        if not os.path.isfile(file_path):
            QMessageBox.warning(self, 'Ошибка', 'Файл не найден.')
            return

        key = self.key_line_edit.text().encode()
        if len(key) != 44:
            QMessageBox.warning(self, 'Ошибка', 'Неправильная длина ключа шифрования.')
            return

        try:
            cipher_suite = Fernet(key)
            with open(file_path, 'rb') as file:
                encrypted_data = file.read()

            decrypted_data = cipher_suite.decrypt(encrypted_data)
        except Exception as e:
            QMessageBox.warning(self, 'Ошибка', f'Не удалось расшифровать данные: {e}')
            return

        try:
            exec(decrypted_data.decode(), {'__name__': '__main__'})
            QMessageBox.information(self, 'Успех', 'Скрипт успешно расшифрован и выполнен.')
        except Exception as e:
            QMessageBox.warning(self, 'Ошибка', f'Ошибка при выполнении скрипта: {e}')

if __name__ == '__main__':
    app = QApplication([])
    script_executor = EncryptedScriptExecutor()
    script_executor.show()
    app.exec()
