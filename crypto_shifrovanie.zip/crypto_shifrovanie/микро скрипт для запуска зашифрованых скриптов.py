import os
from cryptography.fernet import Fernet

def decrypt_and_execute_encrypted_script():
    # Получаем текущую директорию, где находится запущенный скрипт
    current_dir = os.path.dirname(__file__)

    # Путь к зашифрованному скрипту и ключ шифрования
    encrypted_script_path = os.path.join(current_dir, 'шифрование в байткод.enc')  # путь к зашифрованному скрипту
    key = b'lcR5IsXoPO9NszmDzdymqemAMmrVn2WwDAt_Qzp0Aok='  # ваш ключ шифрования

    try:
        cipher_suite = Fernet(key)
        
        # Чтение зашифрованного скрипта
        with open(encrypted_script_path, 'rb') as encrypted_file:
            encrypted_data = encrypted_file.read()

        # Расшифровка и выполнение скрипта
        decrypted_data = cipher_suite.decrypt(encrypted_data)
        exec(decrypted_data.decode(), {'__name__': '__main__'})
    except Exception as e:
        print(f'Ошибка при выполнении расшифрованного скрипта: {e}')

if __name__ == '__main__':
    decrypt_and_execute_encrypted_script()
