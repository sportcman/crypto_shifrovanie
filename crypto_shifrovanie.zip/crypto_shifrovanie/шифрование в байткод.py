import os
import compileall
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox

class CompileScriptApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Компиляция скриптов в байткод')
        self.layout = QVBoxLayout()

        self.file_label = QLabel('Выберите файл Python или директорию для компиляции:')
        self.file_line_edit = QLineEdit()
        self.file_button = QPushButton('Обзор')
        self.file_button.clicked.connect(self.browse_file_or_directory)

        self.compile_button = QPushButton('Компилировать')
        self.compile_button.clicked.connect(self.compile_scripts)

        self.layout.addWidget(self.file_label)
        self.layout.addWidget(self.file_line_edit)
        self.layout.addWidget(self.file_button)
        self.layout.addWidget(self.compile_button)

        self.setLayout(self.layout)

    def browse_file_or_directory(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Выберите файл Python или директорию для компиляции', filter='Python files (*.py *.pyw);;All files (*)')
        if path:
            self.file_line_edit.setText(path)

    def compile_scripts(self):
        path = self.file_line_edit.text()

        if not path:
            QMessageBox.warning(self, 'Ошибка', 'Выберите файл Python или директорию для компиляции.')
            return

        if not os.path.exists(path):
            QMessageBox.warning(self, 'Ошибка', 'Выбранный файл или директория не существует.')
            return

        try:
            if os.path.isfile(path):
                compileall.compile_file(path, force=True)
                QMessageBox.information(self, 'Успех', 'Файл успешно скомпилирован в байткод.')
            elif os.path.isdir(path):
                compileall.compile_dir(path, force=True)
                QMessageBox.information(self, 'Успех', 'Скрипты успешно скомпилированы в байткод.')
        except Exception as e:
            QMessageBox.warning(self, 'Ошибка', f'Ошибка при компиляции: {str(e)}')

if __name__ == '__main__':
    app = QApplication([])
    compile_app = CompileScriptApp()
    compile_app.show()
    app.exec()
