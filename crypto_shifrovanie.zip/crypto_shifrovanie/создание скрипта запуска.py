import sys
import os
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox
from PyQt6.QtCore import Qt

class ScriptGenerator(QWidget):
    def __init__(self):
        super().__init__()
        
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('Script Generator')
        self.setGeometry(100, 100, 400, 200)
        
        layout = QVBoxLayout()
        
        # Input for file name
        self.file_label = QLabel('Имя файла:', self)
        layout.addWidget(self.file_label)
        
        self.file_input = QLineEdit(self)
        layout.addWidget(self.file_input)
        
        # Input for decryption key
        self.key_label = QLabel('Ключ для расшифровки:', self)
        layout.addWidget(self.key_label)
        
        self.key_input = QLineEdit(self)
        layout.addWidget(self.key_input)
        
        # Button to generate the script
        self.generate_button = QPushButton('Создать копию скрипта', self)
        self.generate_button.clicked.connect(self.generate_script)
        layout.addWidget(self.generate_button)
        
        self.setLayout(layout)
    
    def generate_script(self):
        file_name = self.file_input.text()
        decryption_key = self.key_input.text()
        
        if not file_name or not decryption_key:
            QMessageBox.warning(self, 'Ошибка', 'Пожалуйста, заполните все поля.')
            return
        
        options = QFileDialog.Option.DontUseNativeDialog
        save_path, _ = QFileDialog.getSaveFileName(self, "Сохранить файл", "", "Python Files (*.py);;All Files (*)", options=options)
        
        if save_path:
            try:
                with open(save_path, 'w', encoding='utf-8') as file:
                    script_content = f"""
# -*- coding: utf-8 -*-
import os
from cryptography.fernet import Fernet

def decrypt_and_execute_encrypted_script():
    # Получаем текущую директорию, где находится запущенный скрипт
    current_dir = os.path.dirname(__file__)

    # Путь к зашифрованному скрипту и ключ шифрования
    encrypted_script_path = os.path.join(current_dir, '{file_name}')  # путь к зашифрованному скрипту
    key = b'{decryption_key}'  # ваш ключ шифрования

    try:
        cipher_suite = Fernet(key)
        
        # Чтение зашифрованного скрипта
        with open(encrypted_script_path, 'rb') as encrypted_file:
            encrypted_data = encrypted_file.read()

        # Расшифровка и выполнение скрипта
        decrypted_data = cipher_suite.decrypt(encrypted_data)
        exec(decrypted_data.decode(), {{'__name__': '__main__'}})
    except Exception as e:
        print(f'Ошибка при выполнении расшифрованного скрипта: {{e}}')

if __name__ == '__main__':
    decrypt_and_execute_encrypted_script()
"""
                    file.write(script_content)
                QMessageBox.information(self, 'Успех', f'Скрипт успешно сохранен в {save_path}')
            except Exception as e:
                QMessageBox.critical(self, 'Ошибка', f'Не удалось сохранить скрипт: {e}')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    generator = ScriptGenerator()
    generator.show()
    sys.exit(app.exec())
